#ifndef MENU_H
#define MENU_H
#include "pizza.h"
#include "structs.h"
#pragma once

using std::string;

class Menu {
	private:
		int num_pizzas;
		Pizza* pizzas;
		
	public:
		//need to include accessor functions and mutator functions for each private member
		//need to include constructors, copy constructors, assignment operator overload,
		//and destructors where appropriate
		Menu();			//con
		~Menu();		//decon
		Menu & operator=(const Menu &);		// assn overload
		Menu(const Menu &);	// copy


		int get_num_pizza();
		void set_num_pizza(int num_pizzas);
		Pizza * get_pizzas();
		void set_pizzas(Pizza * pizzas);
		void set_from_file();	
		void print_menu();
		void order_selected(int& counter, int upper_bound);
		int newArray(string* ingredients, int num_ingredients, int count);
		int newArray_ex(string* ingredients, int num_ingredients, int count);
		void pizzaArrivals(int& choiceVar, pizzaOrder * new_pizzas, int i);	
	
		int off_menu(int& counter, int upper_bound, pizzaOrder * test);
		void append(int& counter, int upper_bound, pizzaOrder * test, orders person);
		void disp_array(int& counter, int upper_bound, pizzaOrder * test);
		int another_function(int& counter, int upper_bound, pizzaOrder * test, orders person);
		void append(orders person, pizzaOrder * test);
		Menu search_pizza_by_cost(int upper_bound);
		Menu search_pizza_by_ingredients_to_include(string* ingredients, int num_ingredients);
		Menu search_pizza_by_ingredients_to_exclude(string* ingredients, int num_ingredients);
		void add_to_menu(Pizza pizza_to_add);
		void remove_from_menu(int index_of_pizza_on_menu);
		int IntegerError(string s, int& intgr);
};
#endif
