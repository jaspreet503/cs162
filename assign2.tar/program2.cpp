/*********************************************************************
 * ** Program Filename: PizzaParlor.cpp
 * ** Author: Jaspreet Dhillon
 * ** Date: 04/28/2019
 * ** Description: This program mimics a pizza parlor, where there is verified login for employees, and customers who can
 * 		purpose pizzas on the website. Built in functionalities.
 * ** Input: User will input their choice, and be prompted based off such
 * ** Output: Based on users input, they can order pizzas, view menus, remove orders, etc.
 * *********************************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "pizza.h"
#include "structs.h"
#include "restaurant.h"
#include "menu.h"
using namespace std;

int main() {
	Restaurant g;
	int test, test2;
	g.load_data();
	Pizza* selection;
	g.status(test, test2, selection); // this function keeps calling itself over and over, why?
}
	

