#include <iostream>
#include <fstream>
#include "pizza.h"
#include <iomanip>

using namespace std;

/*********************************************************************
 * ** Function: default constructor
 * ** Description: This function is called every time an object of this function is created and sets the values to zero or null
 * ** Parameters: None
 * ** Pre-Conditions: An object of this class is created
 * ** Post-Conditions: An object of this class is initialized
 * *********************************************************************/ 
Pizza::Pizza() {
	ingredients = NULL;
	name = "";
	small_cost = 0;
	medium_cost = 0;
	large_cost = 0;
	num_ingredients = 0; 
}

/*********************************************************************
 * ** Function: Copy constructor
 * ** Description: This function copies information from the prior object into the new object
 * ** Parameters: The old object and hte old objects values
 * ** Pre-Conditions: The user chooses to do a copying assignment on an object
 * ** Post-Conditions: The new object does a deep copy of the old copy
 * *********************************************************************/ 
Pizza::Pizza(const Pizza &old) {
	name = old.name;
	small_cost = old.small_cost;
	medium_cost = old.medium_cost;
	large_cost = old.large_cost;
	num_ingredients = old.num_ingredients;

	ingredients = new string[num_ingredients];
	for (int i = 0; i < num_ingredients; i++) {
		ingredients[i] = old.ingredients[i];
	}
}	

/*********************************************************************
 * ** Function: Assignment operator overload
 * ** Description: This functioncopies information from the prior object into the new object
 * ** Parameters: This object and the old objects values
 * ** Pre-Conditions: The user chooses to do an assignment operator overload on an object
 * ** Post-Conditions: The new object does a deep copy of hte old copy
 * *********************************************************************/ 
Pizza & Pizza::operator=(const Pizza &old) {
	if (this != &old) {
		delete [] ingredients;		

		name = old.name;
		small_cost = old.small_cost;
		medium_cost = old.medium_cost;
		large_cost = old.large_cost;
		num_ingredients = old.num_ingredients;

		ingredients = new string[num_ingredients];
		for (int i = 0; i < num_ingredients; i++) {
			ingredients[i] = old.ingredients[i];
		}	
	}
	return *this;
}

/*********************************************************************
 * ** Function: Destructor
 * ** Description: Deletes all dynamically allocated memory
 * ** Parameters: None
 * ** Pre-Conditions: Object is constructed
 * ** Post-Conditions: Objects memory goes out of scope and this is called to delete the memory
 * *********************************************************************/ 
Pizza::~Pizza() {
	delete [] ingredients;
}

// Accessors & Mutators


/*********************************************************************
 * ** Function: get_name
 * ** Description: Gets the name of the pizza
 * ** Parameters: none
 * ** Pre-Conditions: called from outer class function
 * ** Post-Conditions: Obtains the value of name at any index
 * *********************************************************************/ 
std::string Pizza::get_name() {
	return name;
}

/*********************************************************************
 * ** Function: set name
 * ** Description: Sets the name of the pizza
 * ** Parameters: none
 * ** Pre-Conditions: Called from outer class function
 * ** Post-Conditions: Sets value of the name
 * *********************************************************************/ 
void Pizza::set_name(std::string name) {
	this->name=name;
}

/*********************************************************************
 * ** Function: get num ingredients 
 * ** Description:Get the number of ingredients through another class
 * ** Parameters: none
 * ** Pre-Conditions: Function is accessed
 * ** Post-Conditions: Variable is sent
 * *********************************************************************/ 
int Pizza::get_num_ingredients() {
	return num_ingredients;
}

/*********************************************************************
 * ** Function: set num ingredients
 * ** Description: Sets the number of ingredients from another class
 * ** Parameters: num ingredients
 * ** Pre-Conditions: Function is set from another class
 * ** Post-Conditions: value is changed
 * *********************************************************************/ 
void Pizza::set_num_ingredients(int num_ingredients){
	this->num_ingredients = num_ingredients;
}
/*********************************************************************
 * ** Function: get small cost
 * ** Description: Value of small cost can be obtained in another class
 * ** Parameters: None
 * ** Pre-Conditions: Whenever naother class needs the small cost value
 * ** Post-Conditions: None
 * *********************************************************************/ 
int Pizza::get_small_cost() {
	return small_cost;
}
/*********************************************************************
 * ** Function: set small cost
 * ** Description: Sets the cost of the small pizza from anotehr class
 * ** Parameters: small cost
 * ** Pre-Conditions: Small cost of any pizza needs to be set given its a private variable
 * ** Post-Conditions: small cost is set
 * *********************************************************************/ 
void Pizza::set_small_cost(int small_cost) {
	this->small_cost = small_cost;
}
/*********************************************************************
 * ** Function: get medium cost
 * ** Description: Value of the medium cost can be obtained in any other class
 * ** Parameters: None 
 * ** Pre-Conditions: Whenever another class needs the medium cost value
 * ** Post-Conditions: None
 * *********************************************************************/ 
int Pizza::get_medium_cost() {
	return medium_cost;
}
/*********************************************************************
 * ** Function: set medium cost
 * ** Description: Sets the ost of hte medium pizza from outside the class
 * ** Parameters: medium cost
 * ** Pre-Conditions: Medium cost of any pizza needs to be set given its a private variable
 * ** Post-Conditions: medium cost is set
 * *********************************************************************/ 
void Pizza::set_medium_cost(int medium_cost) {
	this->medium_cost = medium_cost;
}
/*********************************************************************
 * ** Function: get large cost
 * ** Description: Value of large cost can be obtained in any other class
 * ** Parameters: None 
 * ** Pre-Conditions: Whenever another class needs the large cost value
 * ** Post-Conditions: None
 * *********************************************************************/ 
int Pizza::get_large_cost() {
	return large_cost;
}
/*********************************************************************
 * ** Function: Set large cost
 * ** Description: sets the cost of the large pizza from outside of hte class
 * ** Parameters: large cost
 * ** Pre-Conditions: Large cost of any pizza needs to be set given its a private variable
 * ** Post-Conditions: Large cost is set
 * *********************************************************************/ 
void Pizza::set_large_cost(int large_cost) {
	this->large_cost = large_cost;
}
/*********************************************************************
 * ** Function: Get ingredients
 * ** Description: Gets the pointer to the array of ingredients
 * ** Parameters: None
 * ** Pre-Conditions: Whenever called to obtain the private variable
 * ** Post-Conditions: Variable can be accessed in other classes
 * *********************************************************************/ 
std::string * Pizza::get_ingredients() {
	return ingredients;
}

/*********************************************************************
 * ** Function: set ingredients
 * ** Description: Sets the pointer of array of ingredients
 * ** Parameters: none
 * ** Pre-Conditions: Whenever called to set the private variable
 * ** Post-Conditions: Variable can be set in other classes
 * *********************************************************************/ 
void Pizza::set_ingredients(std::string * ingredients) {
	this->ingredients = ingredients;
}

/*********************************************************************
 * ** Function: Set from file
 * ** Description: This function is called in the menu.cpp to take in values from the menu.txt file
 * ** Parameters: menu.txt
 * ** Pre-Conditions: This function is called in menu.cpp and stores values correctly
 * ** Post-Conditions: Array created with new values
 * *********************************************************************/ 
void Pizza::set_from_file(ifstream& menu) {
	menu >> name; 
	menu >>	small_cost;
	menu >> medium_cost;
	menu >> large_cost;
	menu >> num_ingredients;
	ingredients = new string[num_ingredients];
	for (int g = 0; g < num_ingredients; g++) {
		menu >> ingredients[g];
	}
}
