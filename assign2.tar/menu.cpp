#include <iostream>
#include <iomanip>
#include <fstream>
#include "menu.h"
#include <cstdlib>

using namespace std;
using std::string;

/*********************************************************************
 * ** Function: Menu()
 * ** Description: Default constructor, initializes the pizzas array to null and sets num_pizzas to zero
 * ** Parameters: None
 * ** Pre-Conditions: Called every time an object of type Menu is created
 * ** Post-Conditions: None
 * *********************************************************************/ 
Menu::Menu() {
	pizzas = NULL;
	num_pizzas = 0;
}

/*********************************************************************
 * ** Function: Menu
 * ** Description: This is the copy constructor, same description from the restaurant copy constructor
 * ** Parameters: Old menu
 * ** Pre-Conditions: Every time an object is set equal to another to warrant copying from old object to new object
 * ** Post-Conditions: New object now contains values of the old object
 * *********************************************************************/ 
Menu::Menu(const Menu &oldMenu) {
	num_pizzas = oldMenu.num_pizzas;
	pizzas = new Pizza [num_pizzas];
	for (int i = 0; i < num_pizzas; i++) {
		pizzas[i] = oldMenu.pizzas[i];
	}
}

/*********************************************************************
 * ** Function: assignment operator overload
 * ** Description: This function, similar to the copy constructor, does the same exact thing just depends how the user initializes the object
 * ** Parameters: Oldobject
 * ** Pre-Conditions: Description
 * ** Post-Conditions: New object now contains the values of the old object, deep copy so it has its own pointers now too
 * *********************************************************************/ 
Menu & Menu::operator=(const Menu &oldMenu) {
	if (this != &oldMenu) {
		delete [] pizzas;

		num_pizzas = oldMenu.num_pizzas;
		pizzas = new Pizza [num_pizzas];
		for (int i = 0; i < num_pizzas; i++) {
			pizzas[i] = oldMenu.pizzas[i];
		}
	}
	return *this;	
}

/********************************************************************* 
 * ** Function: Destructor
 * ** Description: Called every time object goes out of scope, deletes allocated memory of pizzas
 * ** Parameters: None
 * ** Pre-Conditions: Object must first be instantiated
 * ** Post-Conditions: Objects memory is deleted
 * *********************************************************************/ 
Menu::~Menu() {
	delete [] pizzas;
}

/*********************************************************************
 * ** Function: Setter function for num pizzas
 * ** Description: Allows access in restaurant.cpp to the num_pizzas variable
 * ** Parameters: Num_pizzas
 * ** Pre-Conditions: Accessed by a function in restaurant.cpp
 * ** Post-Conditions: Restaurant.cpp now can set the value
 * *********************************************************************/ 
void Menu::set_num_pizza(int num_pizzas) {
	this->num_pizzas = num_pizzas;
}

/*********************************************************************
 * ** Function: Getter function for num pizzas
 * ** Description: Allows access in restaurant.cpp to the num_pizzas variable
 * ** Parameters: None
 * ** Pre-Conditions: Accessed by a function in restaurant.cpp
 * ** Post-Conditions: Restaurant.cpp can now obtain the value
 * *********************************************************************/ 
int Menu::get_num_pizza() {
	return num_pizzas;
}

/*********************************************************************
 * ** Function: get_pizzas
 * ** Description: Allows access in restaurant.cpp to the pizzas array
 * ** Parameters: None
 * ** Pre-Conditions: Accessed by a function in restaurant.cpp
 * ** Post-Conditions: Restaurant.cpp can now obtain the array
 * *********************************************************************/ 
Pizza * Menu::get_pizzas() {
	return pizzas;
}

/*********************************************************************
 * ** Function: set_pizzas
 * ** Description: Allows access in restaurant.cpp to the pizzas array
 * ** Parameters: None
 * ** Pre-Conditions: Accessed by a function in restaurant.cpp
 * ** Post-Conditions: Restaurant.cpp can now set the array
 * *********************************************************************/ 
void Menu::set_pizzas(Pizza * pizzas) {
	this->pizzas = pizzas;
}

/*********************************************************************
 * ** Function: set_from_file
 * ** Description: This function lods the data from menu.txt file and stores it into an array 
 * ** Parameters: None
 * ** Pre-Conditions: None
 * ** Post-Conditions: Information from the menu.txt file is now stored in a dynamically allocated array
 * *********************************************************************/ 
void Menu::set_from_file() {
	ifstream menu("menu.txt");
	num_pizzas = 0;
	string s;
	while (!menu.eof()) {
		getline(menu, s);
		num_pizzas++;
	}
	num_pizzas = num_pizzas - 1;
	menu.clear();
	menu.seekg(0, ios::beg);
	pizzas = new Pizza[num_pizzas];
	int i = 0;
	while (!menu.eof() && i < num_pizzas) {
		pizzas[i].set_from_file(menu);		
		i++;		
	}
}

/*********************************************************************
 * ** Function: Print_menu
 * ** Description: This function prints the menu, aesthetically to the termainl
 * ** Parameters: None
 * ** Pre-Conditions: The user chooses to print the menu
 * ** Post-Conditions: The menu is printed to the terminal 
 * *********************************************************************/ 
void Menu::print_menu() {
	cout << endl;
	for (int i = 0; i < num_pizzas; i++) {
		cout << left << "(" << i + 1 << ")" << setw(25) << pizzas[i].get_name() <<  setw(5) << pizzas[i].get_small_cost() << setw(5) <<
			pizzas[i].get_medium_cost() << setw(5) <<  pizzas[i].get_large_cost() << setw(5) << pizzas[i].get_num_ingredients();
		for (int g = 0; g < pizzas[i].get_num_ingredients(); g++) {
			cout << setw(20) << pizzas[i].get_ingredients()[g];
		}
		cout << endl;
	}

}

/*********************************************************************
 * ** Function: search pizza by cost
 * ** Description: This function takes the max budget of the user and displays pizzas that fit within their budget
 * ** Parameters: Upper_bound
 * ** Pre-Conditions: This function is called when the user chooses to search by price
 * ** Post-Conditions: This function leads to like ten more because of the twenty line limit.
 * *********************************************************************/ 
Menu Menu::search_pizza_by_cost(int upper_bound) {
	Menu temp; 
	int counter = 0;
	cout << endl;

	for (int i = 0; i < num_pizzas; i++) {
		cout << left << setw(25) << pizzas[i].get_name();
		if (pizzas[i].get_small_cost() <= upper_bound) {
			cout << setw(5) << pizzas[i].get_small_cost();
			counter++;
		}
		else if (pizzas[i].get_small_cost() > upper_bound) {
			cout << setw(5) << "N/A";
		}

		if (pizzas[i].get_medium_cost() <= upper_bound) {
			cout << setw(5) << pizzas[i].get_medium_cost();
			counter++;
		}

		else if (pizzas[i].get_medium_cost() > upper_bound) {
			cout << setw(5) << "N/A";
		}	

		if (pizzas[i].get_large_cost() <= upper_bound) {
			cout << setw(5) << pizzas[i].get_large_cost();
			counter++;
		}
		else if (pizzas[i].get_large_cost() > upper_bound) {
			cout << setw(5) << "N/A";
		}	
		cout << setw(5) << pizzas[i].get_num_ingredients();
		for (int g = 0; g < pizzas[i].get_num_ingredients(); g++)  {
			cout << left << setw(20) << pizzas[i].get_ingredients()[g];	
		}
		cout << endl;
	}
	order_selected(counter, upper_bound);
	return temp;
}


/*********************************************************************
 * ** Function: order_selection
 * ** Description: Crates a new pizzaOrder and passes it, acts as a manger function
 * ** Parameters: counter and upperbound
 * ** Pre-Conditions: User selects to search by price
 * ** Post-Conditions: none
 * *********************************************************************/ 
void Menu::order_selected(int& counter, int upper_bound) {
	pizzaOrder * test;
	test = new pizzaOrder[counter];

	cout << endl;
	disp_array(counter, upper_bound, test);
	off_menu(counter, upper_bound, test);
}

/*********************************************************************
 * ** Function: disp_array
 * ** Description: Creates new function with personalized struct and displays the associated size
 * ** Parameters: Counter, upperbound, and pizzaOrder array
 * ** Pre-Conditions: The user selects search by cost
 * ** Post-Conditions: The user is prompted with a table of pizzas with their chosen choices
 * *********************************************************************/ 
void Menu::disp_array(int& counter, int upper_bound, pizzaOrder * test) {

	int check = 0;
	for (int i = 0; i < num_pizzas; i++) {
		if (pizzas[i].get_small_cost() <= upper_bound) {
			test[check].quantity = pizzas[i].get_small_cost();
			test[check].pizzaName = pizzas[i].get_name();
			test[check].pizzaSize = " S ";
			check++;
		}
		if (pizzas[i].get_medium_cost() <= upper_bound) {
			test[check].quantity = pizzas[i].get_medium_cost();
			test[check].pizzaName = pizzas[i].get_name();
			test[check].pizzaSize = " M ";
			check++;
		}
		if (pizzas[i].get_large_cost() <= upper_bound) {
			test[check].quantity = pizzas[i].get_large_cost();
			test[check].pizzaName = pizzas[i].get_name();
			test[check].pizzaSize = " L ";
			check++;
		}

	}
	for (int i = 0; i < counter; i++) {
		cout << "(" << i+1 << ") " << setw(15) <<  test[i].pizzaSize << setw(25) <<  test[i].pizzaName << setw(25) << test[i].quantity << endl;
	}
}

/*********************************************************************
 * ** Function: another_function
 * ** Description: The user can choose to purchase a pizza or not
 * ** Parameters: counter, orders person, and test pizzaOrder
 * ** Pre-Conditions: User searches for pizzas
 * ** Post-Conditions: User can purchase the pizza or not
 * *********************************************************************/ 
int Menu::another_function(int& counter, int upper_bound, pizzaOrder * test, orders person) {
	int choice;
	string s;
	for (int g = 0; g < person.tempNum; g++) {
		do {
			cout << "\nSelect an option form the list above. You may also enter 0 to cancel this order" << endl;
			cout << "Enter selection: ";
			IntegerError(s, choice);
		} while (choice < 0 || choice > counter);
		person.orderr[g].pizzaName = test[choice-1].pizzaName;
		person.orderr[g].pizzaSize = test[choice-1].pizzaSize;
		if (choice == 0) 
			return 0;
		do {
			cout << "How many " << test[choice-1].pizzaSize << " " << test[choice-1].pizzaName << "? ";
			IntegerError(s, person.orderr[g].quantity);

		} while ( choice < 0 || choice > counter);
	}
}

/*********************************************************************
 * ** Function: append 
 * ** Description: User places an order and their information will be appended onto the new file
 * ** Parameters: Test array
 * ** Pre-Conditions: The user places an order or removes an order
 * ** Post-Conditions: The orders.txt file is appended
 * *********************************************************************/ 
void Menu::append(orders person, pizzaOrder * test) {
	ifstream ordd("orders.txt");
	string s;
	int count = 0;
	while (!ordd.eof()) {
		getline(ordd, s);
		count++;
	}
	ordd.close();
	ofstream ord("orders.txt", ios::app);
	ord << count << " " << person.cust_name << " " << person.cc << " " << person.phone;
	for (int g = 0; g < person.tempNum; g++) {
		ord << " " << person.orderr[g].pizzaName << person.orderr[g].pizzaSize << person.orderr[g].quantity;
	}
	ord << endl;
	ord.close();
	delete [] person.orderr;
	delete [] test;
}

Menu Menu::search_pizza_by_ingredients_to_include(string* ingredients, int num_ingredients) {
	Menu temp;
	int count = 0;
	bool choice;
	for (int i = 0; i < num_pizzas; i++) {
		for (int k = 0; k < num_ingredients; k++) {
			for (int g = 0; g < pizzas[i].get_num_ingredients(); g++) {
				if (pizzas[i].get_ingredients()[g].compare(ingredients[k]) == 0) {
					choice = true;
					break;
				}
				else {
					choice = false;
				}
			}
			if (choice == false)
				break;
		}
		if (choice == true) {
			count++;
		}
	}
	if (count == 0) {
		cout << "\n No pizzas match the search." << endl;
		return temp;
	}
	newArray(ingredients,num_ingredients,count);
	return temp;
}

/*********************************************************************
 * ** Function: newArray
 * ** Description: this function compares ingredients to include, and gives a list of the pizzas with said ingredients
 * ** Parameters: List of ingredients, and number of ingredients
 * ** Pre-Conditions: User chooses to search by ingredients to include
 * ** Post-Conditions: User is prompted with a table of pizzas of their associated ingredients
 * *********************************************************************/ 
int Menu::newArray(string* ingredients, int num_ingredients, int count) {
	count = count * 3;
	pizzaOrder * new_pizzas;
	new_pizzas = new pizzaOrder[count];
	bool choice;
	int checker = 0, choiceVar = 0;
	for (int i = 0; i < num_pizzas; i++) {
		for (int k = 0; k < num_ingredients; k++) {
			for (int g = 0; g < pizzas[i].get_num_ingredients(); g++) {
				if (pizzas[i].get_ingredients()[g].compare(ingredients[k]) == 0) {
					choice = true;
					break;
				}
				else
					choice = false;
			}
			if (choice == false)
				break;
		}

		if (choice == true) {
			checker++;
			pizzaArrivals(choiceVar, new_pizzas, i);
		}
	}
	delete [] ingredients;
	if (checker == 0) {
		cout << setw(15) << "\nNo pizzas match the search" << endl;
		delete [] new_pizzas;
		return 1;
	}

	for (int i = 0; i < count; i++) {
		cout << "(" << i+1 << ") " << setw(15) <<  new_pizzas[i].pizzaSize << setw(25) <<  new_pizzas[i].pizzaName << setw(25) << new_pizzas[i].quantity << endl;
	}
	int five = 500;
	off_menu(count, five, new_pizzas);

}

/*********************************************************************
 * ** Function: off_menu
 * ** Description: This function asks the user if they want to purchase off the menu, or they can choose not to. if they do, they put in their information
 * ** Parameters: Counter, pizza array 
 * ** Pre-Conditions: User seraches for pizzas
 * ** Post-Conditions: Users information can be added to orders.txt if they purchase
 * *********************************************************************/ 
int Menu::off_menu(int& counter, int upper_bound, pizzaOrder * test) {
	string s;
	do {
		cout << "Would you like to place an order off this search result (Yes/No) ? ";
		getline(cin, s);
	} while (!(s == "Yes" || s == "No"));
	if (s == "No") {
		delete [] test;
		return 1;
	}
	if (s == "Yes") {
		orders person;	
		cout << "How many unique pizzas will you be ordering? ";
		IntegerError(s, person.tempNum);

		person.orderr = new pizzaOrder[person.tempNum];
		another_function(counter, upper_bound, test, person);

		cout << "Please provide the following information: " << endl;
		cout << "\nCustomer name: ";
		getline(cin, person.cust_name);
		cout << "\nCredit card number: ";
		getline(cin, person.cc);
		cout << "\nPhone number: ";
		getline(cin, person.phone);


		append(person, test);
	}
}
/*********************************************************************
 * ** Function: newArrayex
 * ** Description: This function creates a new array and compares the ingredients to put into a new array
 * ** Parameters: The old array, list of ingredients
 * ** Pre-Conditions: User chooses to search by ingredients to exclude
 * ** Post-Conditions: User will be prompted with pizzas excluding their ingredients
 * *********************************************************************/ 
int Menu::newArray_ex(string* ingredients, int num_ingredients, int count) {
	count = count * 3;
	pizzaOrder * new_pizzas;
	new_pizzas = new pizzaOrder[count];
	bool choice;
	int checker = 0, choiceVar = 0;
	for (int i = 0; i < num_pizzas; i++) {
		for (int k = 0; k < num_ingredients; k++) {
			for (int g = 0; g < pizzas[i].get_num_ingredients(); g++) {
				if (pizzas[i].get_ingredients()[g].compare(ingredients[k]) == 0) {
					choice = false;
					break;
				}
				else
					choice = true;
			}
			if (choice == true)
				break;
		}

		if (choice == true) {
			checker++;
			pizzaArrivals(choiceVar, new_pizzas, i);
		}
	}
	delete [] ingredients;
	if (checker == 0) {
		cout << setw(15) << "\nNo pizzas match the search" << endl;
		delete [] new_pizzas;
		return 1;
	}

	for (int i = 0; i < count; i++) {
		cout << "(" << i+1 << ") " << setw(15) <<  new_pizzas[i].pizzaSize << setw(25) <<  new_pizzas[i].pizzaName << setw(25) << new_pizzas[i].quantity << endl;
	}
	int five = 500;
	off_menu(count, five, new_pizzas);
}

/*********************************************************************
 * ** Function: PizzaArrivals
 * ** Description: Stores information correctly to new array
 * ** Parameters: old array, arbitrary integer I
 * ** Pre-Conditions: User chooses to exclude ingredients
 * ** Post-Conditions: New array filled
 * *********************************************************************/ 
void Menu::pizzaArrivals(int& choiceVar, pizzaOrder * new_pizzas, int i) {
	new_pizzas[choiceVar].pizzaName = pizzas[i].get_name();
	new_pizzas[choiceVar].pizzaSize = " S ";
	new_pizzas[choiceVar].quantity = pizzas[i].get_small_cost();
	choiceVar++;
	new_pizzas[choiceVar].pizzaName = pizzas[i].get_name();
	new_pizzas[choiceVar].pizzaSize = " M ";
	new_pizzas[choiceVar].quantity = pizzas[i].get_medium_cost();
	choiceVar++;
	new_pizzas[choiceVar].pizzaName = pizzas[i].get_name();
	new_pizzas[choiceVar].pizzaSize = " L ";
	new_pizzas[choiceVar].quantity = pizzas[i].get_large_cost();
	choiceVar++;
}
/*********************************************************************
 * ** Function: serach pizza by ingredients to exclude
 * ** Description: Searches for pizzas with specified ingredients excluded
 * ** Parameters: the ingredients list and number of ingredients
 * ** Pre-Conditions: user choose sto search by excluded ingredients
 * ** Post-Conditions: a list of pizzas excluding the chosen ingredients is shown
 * *********************************************************************/ 
Menu Menu::search_pizza_by_ingredients_to_exclude(string* ingredients, int num_ingredients) {
	Menu temp;
	int count = 0;
	bool choice;
	for (int i = 0; i < num_pizzas; i++) {
		for (int k = 0; k < num_ingredients; k++) {
			for (int g = 0; g < pizzas[i].get_num_ingredients(); g++) {
				if (pizzas[i].get_ingredients()[g].compare(ingredients[k]) == 0) {
					choice = false;
					break;
				}
				else {
					choice = true;
				}
			}
			if (choice == false)
				break;
		}
		if (choice == true) {
			count++;
		}
	}
	newArray_ex(ingredients,num_ingredients,count);
	return temp;
}

/*********************************************************************
 * ** Function: add to menu
 * ** Description: Employee adds pizza to the menu
 * ** Parameters: The pizza to add
 * ** Pre-Conditions: User logs in as an employee and chooses to add a pizza to the menu
 * ** Post-Conditions: the menu is added to the text file
 * *********************************************************************/ 
void Menu::add_to_menu(Pizza pizza_to_add) {
	ofstream menu("menu.txt", ios::app);
	menu << pizza_to_add.get_name() << " ";
	menu << pizza_to_add.get_small_cost() << " ";
	menu << pizza_to_add.get_medium_cost() << " ";
	menu << pizza_to_add.get_large_cost() << " ";
	menu << pizza_to_add.get_num_ingredients();
	for (int i = 0; i < pizza_to_add.get_num_ingredients(); i++) 
		menu << " " << pizza_to_add.get_ingredients()[i];
	menu << endl;
	menu.close();
}

/*********************************************************************
 * ** Function: remove from menu
 * ** Description: User logs in as an employee and removes information from the menu
 * ** Parameters: the user chooses the index on the menu
 * ** Pre-Conditions: user chooses index on the menu to delete
 * ** Post-Conditions: that index is deleted
 * *********************************************************************/ 
void Menu::remove_from_menu(int index_of_pizza_on_menu) { 
	ofstream menu("menu.txt", ios::trunc);
	for (int i = 0; i < num_pizzas; i++) {
		if (i != index_of_pizza_on_menu) {
			menu << pizzas[i].get_name() << " " << pizzas[i].get_small_cost() << " " << pizzas[i].get_medium_cost() << " " << pizzas[i].get_large_cost() << " " << pizzas[i].get_num_ingredients();
			for (int g = 0; g < pizzas[i].get_num_ingredients(); g++) {
				menu << " " <<  pizzas[i].get_ingredients()[g];	
			}
			menu << endl;
		}
	}
	delete [] pizzas;
	set_from_file();
}

/*********************************************************************
 * ** Function: IntegerError 
 * ** Description: Error handles integer values
 * ** Parameters: String and integer
 * ** Pre-Conditions: Whenever called, validates integers
 * ** Post-Conditions: None
 * *********************************************************************/ 
int Menu::IntegerError(string s, int& intgr) {
	bool check = true;
	do {
		if (!check) {
			cout << "Enter a valid Integer: ";
		}
		check = true;    // resets check boolean
		getline(cin, s);

		for (int i = 0; s[i]; i++) {
			if (!isdigit(s[i])) {
				check = false;
			}
		}
	} while (!check); // atoi safe, checked before converted
	intgr = atoi(s.c_str());
	return intgr;
}
