#ifndef STRUCTS_H
#define STRUCTS_H
#include <iostream>
#include <fstream>
#pragma once

using namespace std;



struct employee {
	int id;
	std::string password;
	std::string first_name;
	std::string last_name;
};

struct hours {
	std::string day;
	std::string open_hour;
	std::string close_hour;
};

struct pizzaOrder {
	std::string pizzaName;
	std::string pizzaSize;
	int quantity;	
	
};
struct orders {
	int order_num;
	std::string cust_name;
	std::string cc;
	std::string phone;
	int tempNum;
	pizzaOrder *orderr;

};
#endif
