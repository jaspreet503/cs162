#include <fstream>
#include <iomanip>
#include <cstdlib>
#include "restaurant.h"
#include <cstdlib>
#include <sstream>
#include <cctype>	
#pragma once
using namespace std;

/*********************************************************************
 * ** Function: Restaurant();
 * ** Description: This function is the default constructor
 * ** Parameters: None
 * ** Pre-Conditions: This function sets all values to NULL (for pointers)
 * ** Post-Conditions: Values that are not null can be manipulated in the copy constructor and assignment operator overloads
 * *********************************************************************/ 
Restaurant::Restaurant() {
	employees = NULL;
	week = NULL;
	orderslist = NULL;
	for (int i = 0; i < num_orders; i++) 
		orderslist[i].orderr = NULL;
}

/*********************************************************************
 * ** Function: Restaurant
 * ** Description: This program is the copy constructor when trying to set two objects equal to eachother (deep copy)
 * ** Parameters: Reference to the old object with old objects values
 * ** Pre-Conditions: This function is only called if there is an attempt at copying two objects into one another
 * ** Post-Conditions: A new object can be created based off the values from the old object
 * *********************************************************************/ 
Restaurant::Restaurant(const Restaurant & oldobj) {
	name = oldobj.name;
	phone = oldobj.phone;
	address = oldobj.address;
	menu = oldobj.menu;

	employees = new employee[num_employees];
	for (int i = 0; i < num_employees; i++) {
		employees[i] = 	oldobj.employees[i];
	} 

	week = new hours [7]; 
	for (int i = 0; i < 7; i++) {
		week[i] = oldobj.week[i];
	}
}

/*********************************************************************
 * ** Function: Deconstructor
 * ** Description: Deletes all allocated memory when object is deleted
 * ** Parameters: None
 * ** Pre-Conditions: None
 * ** Post-Conditions: Restaurant object default destructor, when object is out of scope or purposefully deleted.
 * *********************************************************************/ 
Restaurant::~Restaurant() {
	delete [] employees;
	delete [] week; 


	for (int i = 0; i < num_orders-1; i++) {
		delete [] orderslist[i].orderr;
	}
	delete [] orderslist;
}

/*********************************************************************
 * ** Function: Assignment Operator Overload
 * ** Description: This function, similar to the copy constructor, can set two objects equal to eachother (deep copy).
 * ** Parameters: Reference to the old object with old objects values
 * ** Pre-Conditions: This function is only called if there is an attempt at copying two objects into one another
 * ** Post-Conditions: A new object can be created based off the values from the old object
 * *********************************************************************/ 
Restaurant & Restaurant::operator=(const Restaurant & oldobj) {
	if (this != &oldobj) {
		delete [] employees;
		delete [] week;

		name = oldobj.name;
		phone = oldobj.phone;
		address = oldobj.address;
		menu = oldobj.menu;

		// deep copy for employee
		employees = new employee[num_employees];
		for (int i = 0; i < num_employees; i++) {
			employees[i] = oldobj.employees[i];
		}		

		week = new hours[7];
		for (int i = 0; i < 7; i++) {
			week[i] = oldobj.week[i];

		}

	}
	return *this;
}

/*********************************************************************
 * ** Function: load_data_employee()
 * ** Description: This function opens the "employee.txt" and stores the information into the valid array
 * ** Parameters: None
 * ** Pre-Conditions: None, the file is hard coded.
 * ** Post-Conditions: Information from the file will be put into an array.
 * *********************************************************************/ 
void Restaurant::load_data_employee() {
	ifstream employ("employee.txt");
	num_employees = 0;
	string s;
	while (!employ.eof()) {
		num_employees++;
		getline(employ, s);
	}
	num_employees = num_employees - 1;
	employ.clear();
	employ.seekg(0, ios::beg);
	employees = new employee[num_employees];
	int i = 0;
	while (!employ.eof()) {
		employ >> employees[i].id;
		employ >> employees[i].password;
		employ >> employees[i].first_name;
		employ >> employees[i].last_name;
		i++;
	}
	employ.close();
}

/*********************************************************************
 * ** Function: Load_data_restaurant_info
 * ** Description: This function opens the "restaurant_info.txt" and stores the infromation into a dynamically allocated array
 * ** Parameters: None
 * ** Pre-Conditions: None, this file is hard coded
 * ** Post-Conditions: Information from this file will be put into an array
 * *********************************************************************/ 
void Restaurant::load_data_restaurant_info() {
	ifstream rest("restaurant_info.txt");

	getline(rest, name);
	getline(rest, phone);
	getline(rest, address);


	week = new hours[7];
	while (!rest.eof()) {
		for (int g = 0; g < 7; g++) {
			rest >> week[g].day;
			rest >> week[g].open_hour;
			rest >> week[g].close_hour;
		}
	}
	rest.close();
}

/*********************************************************************
 * ** Function: Load_data_orders()
 * ** Description: This function opens the orders.txt file and stores the information into the correct, dynamically allocated array
 * ** Parameters: None
 * ** Pre-Conditions: None, this file is hard coded
 * ** Post-Conditions: Infromation from this file will be put into an array
 * *********************************************************************/ 
void Restaurant::load_data_orders() {
	ifstream order("orders.txt");
	string s; 
	num_orders = 0;
	while (!order.eof()) {
		getline(order, s);
		num_orders++;
	}
	orderslist = new orders [num_orders];
	string *str;
	str = new string[num_orders];
	order.clear();
	order.seekg(0, ios::beg);
	load_data_orders2(order, str);
	delete [] str;
}

/*********************************************************************
 * ** Function: load_data_orders2
 * ** Description: The last function was too long so I put some of the lines in here, same idea
 * ** Parameters: Order ifstream and a string of stringstream
 * ** Pre-Conditions: None
 * ** Post-Conditions: Infromation correct appended into array
 * *********************************************************************/ 
void Restaurant::load_data_orders2(ifstream& order, string * str) {
	int i = 0;
	int counter = 0;
	while (getline(order, str[i])) {
		stringstream test(str[i]);
		counter = 0;
		for (int l = 0; l < str[i].length(); l++) {
			if (str[i].at(l) == ' ')
				counter++;
		}
		orderslist[i].tempNum = (counter - 3) / 3; // formula for finding number of unique orders
		orderslist[i].orderr = new pizzaOrder[orderslist[i].tempNum];
		test >> orderslist[i].order_num;
		test >> orderslist[i].cust_name;
		test >> orderslist[i].cc;
		test >> orderslist[i].phone;
		for (int w = 0; w < orderslist[i].tempNum; w++) {
			test >> orderslist[i].orderr[w].pizzaName;
			test >> orderslist[i].orderr[w].pizzaSize;
			test >> orderslist[i].orderr[w].quantity;
		}
		i++;
	}
}

/*********************************************************************
 * ** Function: load_data
 * ** Description: This function calls for the all the infromation from the four hardcoded text documents
 * ** Parameters: None
 * ** Pre-Conditions: Always called 
 * ** Post-Conditions: Information transferred into correct arrays
 * *********************************************************************/ 
void Restaurant::load_data() {
	menu.set_from_file(); // employee
	load_data_restaurant_info();
	load_data_employee();
	load_data_orders();
}

/*********************************************************************
 * ** Function: Status
 * ** Description: The user can choose to login as an employee, customer, or quit
 * ** Parameters: selection
 * ** Pre-Conditions: None
 * ** Post-Conditions: The user can either be sent to the employee login or the customer menu, or quit the program
 * *********************************************************************/ 
int Restaurant::status(int& customerSelection, int& employeeSelection, Pizza* selection ) {
	string core; // (C)ustomer (OR) (E)mployee
	do {
		cout << "\nWelcome to " << name << " !" << endl;
		cout << "Are you a customer (C) or employee (E) or would you like to quit (Q)? ";
		getline(cin, core);

		if (core == "C") {
			customerMenu(customerSelection, employeeSelection, selection);
		}
		else if (core == "E") {
			login_data(customerSelection, employeeSelection);
		}
		else if (core == "Q") {
			return 1;
		}
	} while (core != "C" || core != "E" || core != "Q");
}


/*********************************************************************
 * ** Function: login_data
 * ** Description: User logs in with their information information is passed to the bool function to validate their login
 * ** Parameters: selections
 * ** Pre-Conditions: User chooses to login as an employee
 * ** Post-Conditions: None
 * *********************************************************************/ 
void Restaurant::login_data(int& customerSelection, int& employeeSelection) {
	bool check;
	do {
		string id_login;
		string password_login;
		cout << "Please enter your ID number: ";
		getline(cin, id_login);
		cout << "Please enter your password: ";
		getline(cin, password_login);

		check = login(id_login, password_login);
	} while (check == 0);
	employeeMenu(customerSelection, employeeSelection);
}

/*********************************************************************
 * ** Function: customerMenu
 * ** Description: The user is output with the possible options from their menu when they login as a customer
 * ** Parameters: Selections
 * ** Pre-Conditions: The user logs in as a customer
 * ** Post-Conditions: The user will be prompted their choice, and given that information
 * *********************************************************************/ 
void Restaurant::customerMenu(int& customerSelection, int& employeeSelection, Pizza* selection) {
	string s;
	do {
		cout << "\n  What would you like to do?     "
			"\n\t1. Search by Cost          "
			"\n\t2. Search by Ingredients   "
			"\n\t3. Place Order             "
			"\n\t4. View Menu               "
			"\n\t5. View Hours              "
			"\n\t6. View Address            "
			"\n\t7. View Phone              "
			"\n\t8. Log Out                 "
			"\n  Selection: ";
		menu.IntegerError(s, customerSelection);	
	} while (!(customerSelection > 0 && customerSelection < 9));
	customerSelect(customerSelection, employeeSelection, selection);
}

/*********************************************************************
 * ** Function: customerSelect
 * ** Description: redirects the user to their menu prompted option based off their reply to the prior function
 * ** Parameters: The customers selection
 * ** Pre-Conditions: User logs in as a customer
 * ** Post-Conditions: They will be redirected to the correct function
 * *********************************************************************/ 
int Restaurant::customerSelect(int& customerSelection, int& employeeSelection, Pizza* selection) {
	cout << endl;
	switch (customerSelection) {
		case 1: search_menu_by_price();
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 2: search_by_ingredients();
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 3: place_order(selection);
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 4: view_menu();
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 5: view_hours();
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 6: view_address();
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 7: view_phone();
			customerMenu(customerSelection, employeeSelection, selection);
			break;
		case 8: return 0; // logout
			break;
	}

}

/*********************************************************************
 * ** Function: employeeMenu
 * ** Description: User logs in as an employee, and this is the menu of choices theyre prompted
 * ** Parameters: selections
 * ** Pre-Conditions: User logs in as an employee
 * ** Post-Conditions: User's choice will be sent to employeeSelection()
 * *********************************************************************/ 
void Restaurant::employeeMenu(int& customerSelection, int& employeeSelection) {
	string s;
	do {
		cout << "\n  What would you like to do?	"
			"\n\t1. Change hours			"
			"\n\t2. View Orders				"
			"\n\t3. Remove order			"
			"\n\t4. Add Item to Menu		"
			"\n\t5. Remove Item from Menu	"
			"\n\t6. View Menu				"
			"\n\t7. View Hours				"
			"\n\t8. View Address			"
			"\n\t9. View Phone				"
			"\n\t10. Log Out				"
			"\n  Selection: ";
		menu.IntegerError(s, employeeSelection);
	} while (!(employeeSelection > 0 && employeeSelection < 11));
	employeeSelect(customerSelection, employeeSelection);
}

/*********************************************************************
 * ** Function: Employeeselect
 * ** Description: This function just redirects to the correct function based off the last function choice
 * ** Parameters: selections
 * ** Pre-Conditions: User logs in as an employee
 * ** Post-Conditions: User will be directed to teh function of their choice
 * *********************************************************************/ 
int Restaurant::employeeSelect(int& customerSelection, int& employeeSelection) {
	switch (employeeSelection) { 
		case 1: change_hours();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 2: view_orders();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 3: remove_orders();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 4: add_to_menu();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 5: remove_from_menu();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 6: view_menu();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 7: view_hours();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 8: view_address();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 9: view_phone();
			employeeMenu(customerSelection, employeeSelection);
			break;
		case 10:return 0;	
			break;
	}
}

/*********************************************************************
 * ** Function: login
 * ** Description: This function cross references the id and password of the employees.txt file to ensure user login
 * ** Parameters: id and password
 * ** Pre-Conditions: User chooses to login as an employee
 * ** Post-Conditions: Access to the employees menu
 * *********************************************************************/ 
bool Restaurant::login(string id, std::string password) {
	int idInt = atoi(id.c_str());
	for (int i = 0; i < num_employees; i++) {
		if (employees[i].id == idInt) {
			if (employees[i].password.compare(password) == 0) {
				return true;
			}
			else {
				break;
			}
		}
	}
	cout << "Incorrect ID or password. Please try again." << endl;
	return false;
}

/*********************************************************************
 * ** Function: View_menu
 * ** Description: This function aesthetically displays the menu of the restaurant (which is always updated) to the terminal
 * ** Parameters: None
 * ** Pre-Conditions: User chooses to see menu, can be either customer or employee
 * ** Post-Conditions: Menu outputted
 * *********************************************************************/ 
void Restaurant::view_menu() {
	menu.print_menu();
}

/*********************************************************************
 * ** Function: View_hours
 * ** Description: Outputs the restaurants hours
 * ** Parameters: None
 * ** Pre-Conditions: User selects to see the restaurants hours
 * ** Post-Conditions: Hours outputted of each day
 * *********************************************************************/ 
void Restaurant::view_hours() {
	cout << left << setw(15) << "Day" << setw(15) << "Open Hour" << setw(15) << "Close Hour" << endl;
	for (int i = 0; i < 7; i++) {
		cout << left << setw(15) << week[i].day << setw(15) << week[i].open_hour << setw(15) << week[i].close_hour << endl;
	}
}

/*********************************************************************
 * ** Function: view_address
 * ** Description: Outputs the restaurants address
 * ** Parameters: none
 * ** Pre-Conditions: User selects to see the restaurants address
 * ** Post-Conditions: Address outputted
 * *********************************************************************/ 
void Restaurant::view_address() {
	cout << "\nRestaurant Address: " << address << endl;
}

/*********************************************************************
 * ** Function: view_phone
 * ** Description: Outputs the restaurants phone number
 * ** Parameters: None
 * ** Pre-Conditions: User selects to see restaurants phone number
 * ** Post-Conditions: Phone number outputted
 * *********************************************************************/ 
void Restaurant::view_phone() {
	cout << "\nRestaurant Phone Number: " << phone << endl;
}

/*********************************************************************
 * ** Function: search_menu_by_price
 * ** Description: Displays the menu by price of each item. Asks the user the max budget they want to search for
 * ** Parameters: None
 * ** Pre-Conditions: User selects to search by price
 * ** Post-Conditions: Table outputted with pizzas that fit in their budget
 * *********************************************************************/ 
void Restaurant::search_menu_by_price() {
	string s;
	int upper_b;
	do {
		cout << "\nWhat is your maximum budget (in dollars)? ";
		menu.IntegerError(s, upper_b);
	} while (upper_b < 1);

	menu.search_pizza_by_cost(upper_b);
	for (int i = 0; i < num_orders; i++) {
		delete [] orderslist[i].orderr;
	}
	delete [] orderslist;
	load_data_orders();
}

/*********************************************************************
 * ** Function: search_by_ingredients
 * ** Description: This function just called to_include or to_exclude from users choice
 * ** Parameters: None
 * ** Pre-Conditions: User chooses to search by ingredients
 * ** Post-Conditions: User can choose to include or exclude ingredient(s).
 * *********************************************************************/ 
void Restaurant::search_by_ingredients() {
	string s;
	do {
		cout << "Would you like to search by ingredients to (I) include or (E) exclude? ";
		getline(cin, s);
	} while (!(s == "E" || s == "I"));

	if (s == "E") 
		to_exclude();
	else if (s == "I")
		to_include();

}

/*********************************************************************
 * ** Function: to_include
 * ** Description: The user chooses to include ingredients from their search and outputs a table based off their customization 
 * ** Parameters: None
 * ** Pre-Conditions: User logs in as a customer
 * ** Post-Conditions: User can order off this menu of included ingredients
 * *********************************************************************/ 
void Restaurant::to_include() {
	string s;
	int items;
	cout << "How many items would you like to include? ";
	menu.IntegerError(s, items);

	string * stringArr;
	stringArr = new string[items];

	for (int i = 0; i < items; i++) {
		cout << "(" << i + 1 << ") What item would you like to include? ";
		getline(cin, stringArr[i]);
	}
	menu.search_pizza_by_ingredients_to_include(stringArr, items);
}

/*********************************************************************
 * ** Function: to_exclude
 * ** Description: The user chooses to exclude ingredients from their search and outputs a table based off their customization
 * ** Parameters: None
 * ** Pre-Conditions: User logs in as a customer
 * ** Post-Conditions: User can order off this menu of excluded ingredients
 * *********************************************************************/ 
void Restaurant::to_exclude() {
	string s;
	int items;
	cout << "How many items would you like to exlude? ";
	menu.IntegerError(s, items);

	string * stringArr;
	stringArr = new string[items];

	for (int i = 0; i < items; i++) {
		cout << "(" << i + 1 << ") What item would you like to exclude? ";
		getline(cin, stringArr[i]);
	}

	menu.search_pizza_by_ingredients_to_exclude(stringArr, items);
}

/*********************************************************************
 * ** Function: place_order
 * ** Description: This function essentially just prints the whole menu and asks the user if they want to order a pizza
 * ** Parameters: Pointer to selection pizza
 * ** Pre-Conditions: User logs in as a customer
 * ** Post-Conditions: Users order is appended onto the order.txt file
 * *********************************************************************/ 
void Restaurant::place_order(Pizza* selection) {
	menu.search_pizza_by_cost(200);
	for (int i = 0; i < num_orders; i++) {
		delete [] orderslist[i].orderr;
	}
	delete [] orderslist;

	load_data_orders();	
}

/*********************************************************************
 * ** Function: remove_orders
 * ** Description: This function removes any order at a given index
 * ** Parameters: None
 * ** Pre-Conditions: The user logs in successfully as an employee
 * ** Post-Conditions: The orders.txt file is truncated and updated with the new information, along with the associated array
 * *********************************************************************/ 
void Restaurant::remove_orders() {
	view_orders();
	string s;
	int choice;
	do {
		cout << "Which order would you like to remove? ";
		menu.IntegerError(s, choice);
	} while (choice < 1 || choice > num_orders);


	ofstream ord("orders.txt", ios::trunc);	
	for (int i = 0; i < num_orders - 1; i++) {
		if (i != (choice- 1)) { 
			if (i >= choice)
				ord << (orderslist[i].order_num - 1) << " ";
			else
				ord << orderslist[i].order_num << " ";
			ord << orderslist[i].cust_name << " ";
			ord << orderslist[i].cc << " ";
			ord << orderslist[i].phone;
			for (int w = 0; w < orderslist[i].tempNum; w++) {
				ord << " " <<orderslist[i].orderr[w].pizzaName;
				ord << " " << orderslist[i].orderr[w].pizzaSize;
				ord << " " <<orderslist[i].orderr[w].quantity;
			}
			ord << endl;
		}
	}       
	for (int i = 0; i < num_orders; i++) {
		delete [] orderslist[i].orderr;
	}
	delete [] orderslist;
	load_data_orders();
}

/*********************************************************************
 * ** Function: change_hours
 * ** Description: This function changes the hours on any specified day, monday, tuesday, etc
 * ** Parameters: None
 * ** Pre-Conditions: The user logs in as an employee
 * ** Post-Conditions: The file is truncated, and updated with the new hours. The array is fixed to hold these new values as well.
 * *********************************************************************/ 
void Restaurant::change_hours() {
	string s;
	bool check;
	int i, d;
	do {
		check = true;
		cout << "Which day would you like to change the hours for? ";
		getline(cin, s);

		for (i = 0; i < 7; i++) {
			if (week[i].day.compare(s) == 0) {
				check = true;
				d = i;
				break;
			} 
			else {
				check = false;
			}
		}	
	} while (check == false);


	cout << "What should the opening time be? ";
	getline(cin, week[d].open_hour);
	cout << "What should the closing time be? ";
	getline(cin, week[d].close_hour);

	trunc_rest();
}

/*********************************************************************
 * ** Function: add_to_menu()
 * ** Description: This function adds a selected pizza to the menu
 * ** Parameters: None
 * ** Pre-Conditions: The user logs in as an employee
 * ** Post-Conditions: The information is appended onto the menu, and the array is updated based off this new infromation
 * *********************************************************************/ 
void Restaurant::add_to_menu() {
	Pizza p;
	string s;
	int temp;

	cout << "Enter Pizza Name: ";
	getline(cin, s);
	p.set_name(s);

	cout << "Enter Pizza Small Cost: ";
	menu.IntegerError(s, temp);
	p.set_small_cost(temp);

	cout << "Enter Pizza Medium Cost: ";
	menu.IntegerError(s, temp);
	p.set_medium_cost(temp);

	cout << "Enter Pizza Large Cost: ";
	menu.IntegerError(s, temp);
	p.set_large_cost(temp);

	cout << "Enter Pizza Number of Ingredients: ";
	menu.IntegerError(s, temp);
	p.set_num_ingredients(temp);

	string *ingredient;
	ingredient = new string[temp];
	for (int i = 0; i < temp; i++) {
		cout << "Enter Ingredient Name: ";
		getline(cin, ingredient[i]);
	}
	p.set_ingredients(ingredient);	

	menu.add_to_menu(p);
}

/*********************************************************************
 * ** Function: remove_from_menu
 * ** Description: This function is called when the user selects to remove something from the menu
 * ** Parameters: None
 * ** Pre-Conditions: User logs in as an employee
 * ** Post-Conditions: Selected order at an index is removed from the file and the array (along with a pushback happening)
 * *********************************************************************/ 
void Restaurant::remove_from_menu() {
	menu.print_menu();
	int g; string s;
	cout << endl;
	do {
		cout << "Which pizza would you like to remove?" << endl;
		menu.IntegerError(s, g);
	} while (g < 1 || g > menu.get_num_pizza());
	g--;	
	menu.remove_from_menu(g);
}

/*********************************************************************
 * ** Function: view_orders
 * ** Description: This function allows the user to view the orders from the orders.txt file
 * ** Parameters: None
 * ** Pre-Conditions: The user logs in as an employee
 * ** Post-Conditions: Table output with the information of each order
 * *********************************************************************/ 
void Restaurant::view_orders() {
	for (int i = 0; i < num_orders - 1; i++) {
		cout << orderslist[i].order_num << " " << orderslist[i].cust_name << " " << orderslist[i].cc << " " <<  orderslist[i].phone;
		for (int w = 0; w < orderslist[i].tempNum; w++) {
			cout << " " <<  orderslist[i].orderr[w].pizzaName << " " <<orderslist[i].orderr[w].pizzaSize << " " << orderslist[i].orderr[w].quantity;

		}
		cout << endl;
	}
}

/*********************************************************************
 * ** Function: trunc_rest()
 * ** Description: This function truncates the information onto the restaurant_info.txt file
 * ** Parameters: None
 * ** Pre-Conditions: When the file needs to be rewritten with new information, this function will be called.
 * ** Post-Conditions: restaurant_info.txt truncated with updated infromation
 * *********************************************************************/ 
void Restaurant::trunc_rest() {
	ofstream rest("restaurant_info.txt", ios::trunc);

	rest << name << endl;
	rest << phone << endl;
	rest << address << endl;
	for (int g = 0; g < 7; g++) {
		rest << week[g].day << " ";
		rest << week[g].open_hour << " ";
		rest << week[g].close_hour << endl;
	}
}
