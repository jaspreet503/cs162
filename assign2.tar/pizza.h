#ifndef PIZZA_H
#define PIZZA_H
#pragma once
#include "structs.h"

using namespace std;
class Pizza {
	private:
		std::string name;
		int small_cost;
		int medium_cost;
		int large_cost;
		int num_ingredients;
		std::string* ingredients;
	public:
		Pizza();
		Pizza(const Pizza &);
		Pizza & operator=(const Pizza &);
		~Pizza(); 
		void set_name(string);
		std::string get_name();
		void set_num_ingredients(int);
		int get_num_ingredients();
		void set_small_cost(int);
		int get_small_cost();
		void set_medium_cost(int);
		int get_medium_cost();
		void set_large_cost(int);
		int get_large_cost();
		std::string * get_ingredients();
		void set_ingredients(string*);	
		void set_from_file(ifstream&);
};
#endif
