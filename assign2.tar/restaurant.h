#ifndef RESTAURANT_H
#define RESTAURANT_H

#include "structs.h"
#include "pizza.h"
#include "menu.h"

class Restaurant {
	private:
		Menu menu;
		employee* employees;
		hours* week;
		orders* orderslist; // Created a struct for taking in the users information when they place an order, and the items of their order
		int num_employees; // Useful for number of employees, and which calculating the number of employees in the text file. Also used in the copy and assignment overload constructors
		int num_orders; // Same as num_employees
		std::string name;
		std::string phone;
		std::string address;
	public:
		//need to include accessor functions and mutator functions for each private member
		Restaurant();
		~Restaurant();
		Restaurant(const Restaurant &);
		Restaurant & operator=(const Restaurant &);
		//need to include constructors, copy constructors, assignment operator overload,
		//and destructors where appropriate
		void load_data();
		void load_data_employee(); //reads from files to correctly populate menu, employees, hours, etc.
		void load_data_restaurant_info(); 
		void load_data_orders();

		int status(int& customerSelection, int& employeeSelection, Pizza* selection);
		void login_data(int& customerSelection, int& employeeSelection);
		void customerMenu(int& employeeSelection, int& customerSelection, Pizza* selection);
		int customerSelect(int& customerSelection, int& employeeSelection, Pizza* selection);
		void employeeMenu(int& customerSelection, int& employeeSelection);
		int employeeSelect(int& customerSelection, int& employeeSelection);

		void to_include();
		void to_exclude();
		void load_data_orders2(ifstream& order, string * str);
		bool login(string id, std::string password);
		void view_menu();
		void view_hours();
		void view_address();
		void view_phone();
		void search_menu_by_price();
		void search_by_ingredients();
		void place_order(Pizza* selection);
		void change_hours();
		void add_to_menu();
		void remove_from_menu();
		void view_orders();
		void remove_orders();
		void trunc_rest();
};
#endif
