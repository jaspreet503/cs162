/******************************************************
 * ** Program: wizard_catalog.cpp
 * ** Author: Jaspreet Dhillon
 * ** Date: 04/11/2019
 * ** Description: This program has the user login as a wizard (login will be verified) and user can choose to output
 * 			 information to the terminal, or output information to a file of their choosing
 * ** Input: This program takes in the user's login information and asks which form of sorted information they would like.
 * 			 They also get the choice between having the information printed to the screen or a file of their choosing.
 * ** Output: The user, upon successful login, will be greeted with their title, ID, status, and beard length. They will
 * 			 then have the choice to view information from the spellbork sorted by page number, effect, or average succes rate. 
 * ******************************************************/

#include "./program1.h"
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <cstdlib>

using namespace std;

/*********************************************************************
 * ** Function: get_wizard_firstL
 * ** Description: This function reads the wizards.txt file and takes the first line to allocate
 * 		the correct array size 
 * ** Parameters: Opens the wizards.txt file and creates a reference to the integer of number of wizards
 * ** Pre-Conditions: None
 * ** Post-Conditions: Uses wizNum to allocate array of wizard * struct of correct size
 * *********************************************************************/ 
void get_wizard_firstL(ifstream& wiz, int& wizNum) {
	string s;
	getline(wiz, s);
	wizNum = atoi(s.c_str());
}

/*********************************************************************
 * ** Function: wizard * create_wizard
 * ** Description: This function creates an array of struct wizard using the size of wizNum
 * ** Parameters: Takes wizNum from get_wizard_firstL
 * ** Pre-Conditions: Wizards.txt file is opened in the correct argument
 * ** Post-Conditions: Array will be filled with the rest of the data from wizards.txt
 * *********************************************************************/ 
wizard * create_wizard(int wizNum) {
        struct wizard * create_wizard = new struct wizard[wizNum];
        return create_wizard;
}

/*********************************************************************
 * ** Function: get_wizards_data
 * ** Description: Reads through the wizards.txt file and saves the correct element in the struct array
 * ** Parameters: Creates a pointer to wizard * create_wizard, and wiznum
 * ** Pre-Conditions: The wizards.txt file is opened in the correct argument
 * ** Post-Conditions: Users login info will be checked against the ID/Password of this struct array
 * *********************************************************************/ 
void get_wizard_data(ifstream& wiz, struct wizard * create_wizard, int wizNum ) {
  	int i = 0;
  	while(wiz) {
  		wiz >> create_wizard[i].name;
  		wiz >> create_wizard[i].id;
  		wiz >> create_wizard[i].password;
  		wiz >> create_wizard[i].position_title;
  		wiz >> create_wizard[i].beard_length;
  		i++;
  	}
}

/*********************************************************************
 * ** Function: get_wizard_id
 * ** Description: Prompts user for their ID for login
 * ** Parameters: Creates int to their id to check against create_wizard[i].id
 * ** Pre-Conditions: None
 * ** Post-Conditions: Information checked against database
 * *********************************************************************/ 
void get_wizard_id(int& wizIDint) {
	string wizID;
	cout << "Please enter your id: ";
        wizIDint = IntegerError(wizID, wizIDint);
}

/*********************************************************************
 * ** Function: get_wizard_pass
 * ** Description: Prompts user for the password associated with their ID for login
 * ** Parameters: Creates string to their password 
 * ** Pre-Conditions: None
 * ** Post-Conditions: Information checked (along with ID) against database (create_wizard[i].password)
 * *********************************************************************/ 
void get_wizard_pass(string& wizPASS) {
	cout << "Please enter your password: ";
	getline(cin, wizPASS);
}

/*********************************************************************
 * ** Function: check_wizard_login
 * ** Description: Checks the wizard ID and Password against the database to validate credentials
 * ** Parameters: Takes in wizard login ID, Password, the struct array, and creates a variable for
 * 		the index at which the users information coincides
 * ** Pre-Conditions: User enters their username and password
 * ** Post-Conditions: If user's information is valid, they will be logged in. If not, prompted for new info
 * 		(3 times before program self exits)
 * *********************************************************************/ 
int check_wizard_login(int wizIDint, string wizPASS, struct wizard * create_wizard, int wizNum, int& wizTitle) {
	int count = 0;
	do {
		get_wizard_id(wizIDint);
		get_wizard_pass(wizPASS);
		for (int i = 0; i < wizNum; i++) {
			if (wizIDint == create_wizard[i].id) {
				if (wizPASS.compare(create_wizard[i].password) == 0) {
					wizTitle = i;
					return i;
				}
			}			
 		}	
		count++;
		cout << setw(10) <<  "Incorrect id or password." << endl;
	} while (count < 3);
	cout << "Too many incorrect tries!" << endl;
	exit(0);
}

/*********************************************************************
 * ** Function: greet_wizard
 * ** Description: Greets the wizard when they log in
 * ** Parameters: Wizards index of login, and the entire struct array
 * ** Pre-Conditions: User logs in successfully
 * ** Post-Conditions: None
 * *********************************************************************/ 
void greet_wizard(int wizTitle, struct wizard * create_wizard) {
	cout << "\nWelcome " << create_wizard[wizTitle].name << endl;
	cout << "ID: " << create_wizard[wizTitle].id << endl;
	cout << "Status: " << create_wizard[wizTitle].position_title << endl;
	cout << "Beard Length: " << create_wizard[wizTitle].beard_length << endl << endl;
}

/*********************************************************************
 * ** Function: get_spellbook_firstL
 * ** Description: This function gets the first line of the spellbooks.txt file to create a dynamic array of structs
 * 		of that size
 * ** Parameters: Opens the spellbook.txt file and stores the array value in spellbookNum
 * ** Pre-Conditions: User logs in successfully
 * ** Post-Conditions: Value used for size of dynamic array
 * *********************************************************************/ 
void get_spellbook_firstL(ifstream& spellb, int& spellbookNum) {
        string s;
        getline(spellb, s);
        spellbookNum = atoi(s.c_str());
}

/*********************************************************************
 * ** Function: spellbook * create_spellbook
 * ** Description: Dynamically allocates array of spellbook size spellbookNum
 * ** Parameters: spellbookNum
 * ** Pre-Conditions: User logs in successfully
 * ** Post-Conditions: Array will be filled from ifstream
 * *********************************************************************/ 
spellbook * create_spellbook(int spellbookNum) {
        struct spellbook * create_spellbook = new struct spellbook[spellbookNum];
        return create_spellbook;
}

/*********************************************************************
 * ** Function: spell * create_spell
 * ** Description: Function creates a dynamic list of arrays for each index of spellbook * create_spellbook
 * ** Parameters: Arbitrary value that will be taken as an argument
 * ** Pre-Conditions: User logs in successfully, spellbook is read
 * ** Post-Conditions: Spells can be read into this array
 * *********************************************************************/ 
spell * create_spell(int& k) {
        struct spell * create_spell = new struct spell[k];
        return create_spell;
}

/*********************************************************************
 * ** Function: get_spellbook_data
 * ** Description: Acquires the values from spellbooks.txt for both spellbooks and each spell
 * ** Parameters: Size of the array of spellbooks, and the spellbook array itself
 * ** Pre-Conditions: User successfully logs in, submits valid argument for spellbooks.txt
 * ** Post-Conditions: User can use these arrays to sort information in a later menu
 * *********************************************************************/ 
void get_spellbook_data(ifstream& spellb, struct spellbook * create_spellbook, int spellbookNum ) {
	int i = 0, k;
        while(spellb && (i < spellbookNum)) {
		k = 0;
		spellb >> create_spellbook[i].title;
		spellb >> create_spellbook[i].author;
                spellb >> create_spellbook[i].num_pages;
                spellb >> create_spellbook[i].edition;
                spellb >> create_spellbook[i].num_spells;
		create_spellbook[i].s = create_spell(create_spellbook[i].num_spells);
		for (int g = 0; g < create_spellbook[i].num_spells; g++ ) {
			get_spell_data(create_spellbook[i].s, k, spellb);
			k++;
		}
		i++;
	} // end While
}

/*********************************************************************
 * ** Function: get_spellbook_data
 * ** Description: This function is called each time the prior function reaches a spell
 * ** Parameters: Spellbook array, arbitrary value of (g) which will be changed as an argument
 * ** Pre-Conditions: Spellbook is correctly dynamically allocated
 * ** Post-Conditions: Function is called iteritavly for values to be taken in
 * *********************************************************************/ 
void get_spell_data(struct spell * create_spell, int &g, ifstream& spellb) {
	spellb >> create_spell[g].name;
        spellb >> create_spell[g].success_rate;
        spellb >> create_spell[g].effect;
}

/*********************************************************************
 * ** Function: sort_page
 * ** Description: Information is sorted through each spellbook by ascending page number. Spellbooks including "death" or "poison" are hidden for student wizards.
 * ** Parameters: spellbookNum, writeorcout, wizTitle, create_wizard
 * ** Pre-Conditions: User selects (1)
 * ** Post-Conditions: information outputted to either terminal or file depending on their choice of (writeorcout) (1 or 2)
 * *********************************************************************/ 
void sort_page(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) {
	spellbook temp;
	for (int i =0; i < spellbookNum; i++) {
		for (int j = i ; j < spellbookNum; j++) {
			if(create_spellbook[i].num_pages > create_spellbook[j].num_pages) {
				temp = create_spellbook[i];
				create_spellbook[i] = create_spellbook[j];
				create_spellbook[j] = temp;
			}
		}
	}
	if (writeorcout == 1)
		sort_page_print_1(create_spellbook, spellbookNum, writeorcout, wizTitle, create_wizard);
	if (writeorcout == 2)
		sort_page_print_2(create_spellbook, spellbookNum, writeorcout, wizTitle, create_wizard);
}

/*********************************************************************
 * ** Function: sort_page_print_1
 * ** Description: User selects (1) and to print to terminal. Outputs the information title and number of pages ascending
 * ** Parameters: Many
 * ** Pre-Conditions: User selects (1) and to print to terminal
 * ** Post-Conditions: Information outputted to terminal
 * *********************************************************************/ 
void sort_page_print_1(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) {
	bool check = true;
	cout << left << setw(25) << "\nTitle" << "Number of Pages" << endl;
	cout << left << setw(25) << "-----" << "----------------" << endl;
	for (int i = 0; i < spellbookNum; i++) {
		check = true;
		for (int g = 0; g < create_spellbook[i].num_spells; g++) {
			if ((create_spellbook[i].s[g].effect == "death" || create_spellbook[i].s[g].effect == "poison")
			     && create_wizard[wizTitle].position_title == "Student") {
				check = false;			
			}
		}
		if (check == true)  {
			cout << left << setw(25) << create_spellbook[i].title << create_spellbook[i].num_pages << endl; 
		}
	}
	cout << endl;
}
/*********************************************************************
 * ** Function: sort_page_print_2
 * ** Description: User selects (1) and to print to file. Outputs the information title and number of pages ascending
 * ** Parameters: Many
 * ** Pre-Conditions: User selects (1) and to print to file
 * ** Post-Conditions: Information saved to users chosen file
 * *********************************************************************/ 
void sort_page_print_2(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) {
	string fileName;
	cout << "Enter the file name: ";
	getline(cin, fileName);
	ofstream myfile(fileName.c_str(), fstream::app);

	myfile << left << setw(25) << "\nTitle" << "Number of Pages" << endl;
	myfile << left << setw(25) << "-----" << "----------------" << endl;
	bool check = true;		
	for (int i = 0; i < spellbookNum; i++) {
		check = true;
                for (int g = 0; g < create_spellbook[i].num_spells; g++) {
                	if ((create_spellbook[i].s[g].effect == "death" || create_spellbook[i].s[g].effect == "poison")
			     && create_wizard[wizTitle].position_title == "Student") {
                        	check = false;
                        }
		}
                if (check == true)  {
                	myfile << left << setw(25) << create_spellbook[i].title << create_spellbook[i].num_pages << endl;
                }
	}	
	myfile << endl;
	cout << endl;
	cout << "Appended requested information to file." << endl << endl;
}

/*********************************************************************
 * ** Function: sort_effect_cout
 * ** Description: User wants their information printed to a terminal, poison and death hidden for students
 * ** Parameters: Many
 * ** Pre-Conditions: User selects (2) and to print to terminal
 * ** Post-Conditions: User is provided output in their chosen file of the spells sorted
 * *********************************************************************/ 
void sort_effect_cout (int writeorcout, struct spellbook * create_spellbook, int spellbookNum, struct wizard * create_wizard, int wizTitle) {
	for (int t = 0; t < 5; t++) {	
		for (int i = 0; i < spellbookNum; i++) {
			for (int g = 0; g < create_spellbook[i].num_spells; g++) {
				if (create_spellbook[i].s[g].effect == "bubble" && t == 0) {
					cout << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
				}
				if (create_spellbook[i].s[g].effect == "memory_loss" && t == 1) {
					cout << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
				}
				if (create_spellbook[i].s[g].effect == "fire" && t == 2) { 
					cout << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl; 
				}
				if (create_spellbook[i].s[g].effect == "poison" && t == 3 && create_wizard[wizTitle].position_title != "Student") { 
					cout << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl; 
				}	
				if (create_spellbook[i].s[g].effect == "death" && t == 4 && create_wizard[wizTitle].position_title != "Student") { 
					cout << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl; 
				}
			}
		}
	}
	cout << endl;
}

/*********************************************************************
 * ** Function: sort_effect_ofstr
 * ** Description: User wants their information printed to a file, poison and death hidden for students
 * ** Parameters: Many
 * ** Pre-Conditions: User selects (2) and to print to file
 * ** Post-Conditions: User is provided output in their chosen file of the spells sorted
 * *********************************************************************/ 
void sort_effect_ofstr (int writeorcout, struct spellbook * create_spellbook, int spellbookNum, struct wizard * create_wizard, int wizTitle) {
	string fileName;
	cout << "Enter the file name: ";
	getline (cin, fileName);
	ofstream myfile(fileName.c_str(), fstream::app);
	for (int t = 0; t < 5; t++) {
	        for (int i = 0; i < spellbookNum; i++) {
	                for (int g = 0; g < create_spellbook[i].num_spells; g++) {
	                        if (create_spellbook[i].s[g].effect == "bubble" && t == 0) {
        	                        myfile << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
        	                }
        	                if (create_spellbook[i].s[g].effect == "memory_loss" && t == 1) {
        	                        myfile << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
        	                }
	                        if (create_spellbook[i].s[g].effect == "fire" && t == 2) {
	                                myfile << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
	                        }
	                        if (create_spellbook[i].s[g].effect == "poison" && t == 3 && create_wizard[wizTitle].position_title != "Student") {
	                                myfile << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
	                        }
	                        if (create_spellbook[i].s[g].effect == "death" && t == 4 && create_wizard[wizTitle].position_title != "Student") {
	                                myfile << left << setw(15) << create_spellbook[i].s[g].effect << create_spellbook[i].s[g].name << endl;
                        	}
                	}
        	}
	}
	cout << endl;
	cout << "Appended requested information to file." << endl << endl;;
}

/*********************************************************************
 * ** Function: sort_success_pre
 * ** Description: This function calculates the average success rate in each spellbook
 * ** Parameters: spellbookNum, writeorcout
 * ** Pre-Conditions: User choses (3)
 * ** Post-Conditions: Information sorted, and leads to "sort_success"
 * *********************************************************************/ 
void sort_success_pre(struct spellbook * create_spellbook, int spellbookNum, int writeorcout) {
	float avg = 0;
        for (int i = 0; i < spellbookNum; i++) {
                avg = 0;
                for (int g = 0; g < create_spellbook[i].num_spells; g++) {
                        avg = avg + create_spellbook[i].s[g].success_rate;
                }
                create_spellbook[i].avg_success_rate = (float) avg / (float) create_spellbook[i].num_spells;
        }
}

/*********************************************************************
 * ** Function: Sort_success
 * ** Description: Function sorts information based off of average success rate of each spellbook
 * ** Parameters: Many
 * ** Pre-Conditions: User chooses (3)
 * ** Post-Conditions: User's information is sorted properly
 * *********************************************************************/ 
void sort_success(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) {
        spellbook temp;
	for (int i =0; i < spellbookNum; i++) {
                for (int j = i ; j < spellbookNum; j++) {
                        if(create_spellbook[i].avg_success_rate < create_spellbook[j].avg_success_rate) {
                                temp = create_spellbook[i];
                                create_spellbook[i] = create_spellbook[j];
                                create_spellbook[j] = temp;
	                 }
                }
        }
	cout<<endl;

	if (writeorcout == 1)
                sort_success_print_1(create_spellbook, spellbookNum, writeorcout, wizTitle, create_wizard);
        if (writeorcout == 2)
                sort_success_print_2(create_spellbook, spellbookNum, writeorcout, wizTitle, create_wizard);
}

/*********************************************************************
 * ** Function: sort_success_print
 * ** Description: This function prints to the terminal. Ensures students dont see "death" or "poison"
 * ** Parameters: Many
 * ** Pre-Conditions: User selects "Sort spellbooks by average success rate"
 * ** Post-Conditions: User is prompted with their information in their chose file
 * *********************************************************************/ 
void sort_success_print_1(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) {
        bool check = true;
                cout << left << setw(25) << "\nTitle" << "Avg. Success Rate" << endl;
                cout << left << setw(25) << "-----" << "----------------" << endl;
                for (int i = 0; i < spellbookNum; i++) {
                        check = true;
                        for (int g = 0; g < create_spellbook[i].num_spells; g++) {
                                if ((create_spellbook[i].s[g].effect == "death" || create_spellbook[i].s[g].effect == "poison") && create_wizard[wizTitle].position_title == "Student") {
                                        check = false;
                                }
                        }
                        if (check == true)  {
                                cout << left << setw(25) << create_spellbook[i].title << create_spellbook[i].avg_success_rate << endl;
                        }
                }
	cout << endl;

}

/*********************************************************************
 * ** Function: sort_success_print_2
 * ** Description: This function prints to a file. Ensures students dont see "death" or "poison"
 * ** Parameters: Many
 * ** Pre-Conditions: User selects "Sort spellbooks by average success rate"
 * ** Post-Conditions: User is prompted with their information in their chosen file
 * *********************************************************************/ 
void sort_success_print_2(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) {
	string fileName;
      	cout << "Enter the file name: ";
        getline(cin, fileName);
        ofstream myfile(fileName.c_str(), fstream::app);
        
	myfile << left << setw(25) << "\nTitle" << "Avg. Success Rate" << endl;
        myfile << left << setw(25) << "-----" << "----------------" << endl;
        bool check = true;
        for (int i = 0; i < spellbookNum; i++) {
        	check = true;
                for (int g = 0; g < create_spellbook[i].num_spells; g++) {
                	if ((create_spellbook[i].s[g].effect == "death" || create_spellbook[i].s[g].effect == "poison") && create_wizard[wizTitle].position_title == "Student") {
                        	 check = false;
                        }
		}
                if (check == true)  {
                	myfile << left << setw(25) << create_spellbook[i].title << create_spellbook[i].avg_success_rate << endl;
                }
        }
	cout << endl; 
	cout << "Appended requested information to file." << endl << endl;
}

/*********************************************************************
 * ** Function: spell_option
 * ** Description: This function asks the user which way they want the information sorted
 * ** Parameters: Many
 * ** Pre-Conditions: user successfully logs in
 * ** Post-Conditions: User will be asked which way they want info sorted, and which way they want it output
 * *********************************************************************/ 
void spell_option(int& writeorcout, int spellbookNum, struct spellbook * create_spellbook, struct wizard * create_wizard, int wizTitle, int& option, int wizNum) {
	string s;
	do {

	cout << "Which option would you like to choose?"
		"\n(1) Sort spellbooks by number of pages"
		"\n(2) Group spells by their effect"
		"\n(3) Sort spellbooks by average success rate"
		"\n(4) Quit" << endl;
		option = IntegerError(s, option);

	} while (!(option > 0 && option <= 4)); 
	
	if (option == 4) {
		delete_info(create_wizard, wizNum, create_spellbook, spellbookNum);
		exit(0);	
	}
}

/*********************************************************************
 * ** Function: spell_cout
 * ** Description: User chooses if they want to print to screen or to file
 * ** Parameters: A bunch
 * ** Pre-Conditions: User successfully logs in, selects any of the first three options (not (4) quit)
 * ** Post-Conditions: The user will be presented with the information they chose and the output they chose
 * *********************************************************************/ 
void spell_cout(int& writeorcout, int spellbookNum, struct spellbook * create_spellbook, struct wizard * create_wizard, int wizTitle, int option) {	
	string s;	
	do {
	cout << "\nHow would you like the information recorded?"
		"\n(1) Print to screen"
		"\n(2) Print to file" << endl;
		writeorcout = IntegerError(s, writeorcout);
	} while (!(writeorcout == 1 || writeorcout == 2));

	switch (option) {
		case 1: sort_page(create_spellbook, spellbookNum, writeorcout, wizTitle, create_wizard);
			break;
		case 2: if (writeorcout == 1)
				sort_effect_cout(writeorcout, create_spellbook, spellbookNum, create_wizard, wizTitle);
			else if (writeorcout == 2)
				sort_effect_ofstr(writeorcout, create_spellbook, spellbookNum, create_wizard, wizTitle);
			break;
		case 3: sort_success(create_spellbook, spellbookNum, writeorcout, wizTitle, create_wizard);
			break;
	}
}

/*********************************************************************
 * ** Function: call_all_spell
 * ** Description: This program is the manager of all functions. It repeatedly loops the program until user quits
 * ** Parameters: Everything
 * ** Pre-Conditions: User logs in successfully
 * ** Post-Conditions: None
 * *********************************************************************/ 
void call_all_spell(ifstream& wiz, int wizIDint, string wizPASS, ifstream& spellb, int writeorcout, int& spellbookNum, int spellCounter, int wizNum, int& wizTitle, int& option) {
        get_wizard_firstL(wiz, wizNum);
        wizard * create_wizardd = create_wizard(wizNum);
        get_wizard_data(wiz, create_wizardd, wizNum);
        check_wizard_login(wizIDint, wizPASS, create_wizardd, wizNum, wizTitle);
        greet_wizard(wizTitle, create_wizardd);

	get_spellbook_firstL(spellb, spellbookNum);
	spellbook * create_spellbooks = create_spellbook(spellbookNum);
	get_spellbook_data(spellb, create_spellbooks, spellbookNum);
	sort_success_pre(create_spellbooks, spellbookNum, writeorcout);
	wiz.close();
	spellb.close();	
	while(1) { // Infinite loop until user exits	
		spell_option(writeorcout, spellbookNum, create_spellbooks, create_wizardd, wizTitle, option, wizNum);
		spell_cout(writeorcout, spellbookNum, create_spellbooks, create_wizardd, wizTitle, option);
	}
		delete_info(create_wizardd, wizNum, create_spellbooks, spellbookNum);

}

/*********************************************************************
 * ** Function: delete_info
 * ** Description: Deletes the dynamically allocated struct array of wizards, and spellbooks (including each spell array *s)
 * ** Parameters: Takes in the wizard num, spellbook num, and both struct arrays (spellbook and wizard)
 * ** Pre-Conditions: User's login is valid 
 * ** Post-Conditions: None
 * *********************************************************************/ 
void delete_info(wizard * create_wizard, int wizNum, spellbook * create_spellbook, int spellbookNum) {
	for (int i = 0; i < spellbookNum; i++) {
                delete []  create_spellbook[i].s;
        }
	delete [] create_spellbook;
	delete [] create_wizard;
}

/*********************************************************************
 * ** Function: IntegerError
 * ** Description: Validates intereger input
 * ** Parameters: User enters a string, the string is then converted to an int after it is validated
 * ** Pre-Conditions: User enters a value where IntegerError is called
 * ** Post-Conditions: If correct, value stored. If incorrect data type, value called for again.
 * *********************************************************************/ 
int IntegerError(string s, int& intgr) {
	bool check = true;
	do {
		if (!check) {	
			cout << "Enter a valid Integer: ";
	        }
		check = true;    // resets check boolean
		getline(cin, s);
	
		for (int i = 0; s[i]; i++) {
			if (!isdigit(s[i])) {
        		    check = false;
        	    	}	
		}

	} while (!check); // atoi safe, checked before converted
    	intgr = atoi(s.c_str());
    	return intgr;
}
