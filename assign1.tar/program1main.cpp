#include "./program1.h"
#include <iostream>
#include <fstream>
int main(int argc, char ** argv) {
        ifstream wiz(argv[1]);
        ifstream spellb(argv[2]);

        if (!(wiz.good() && spellb.good())) {
                std::cout << "One or more of the files do not exist. \n ... Program ending ..." << std::endl;
                return 1;
        }
        else {
                int wizTitle, wizNum, wizIDint, writeorcout, spellbookNum, spellCounter, option;
                string wizPASS;

                call_all_spell(wiz, wizIDint, wizPASS, spellb, writeorcout, spellbookNum, spellCounter, wizNum, wizTitle, option);

        }
}

