#include <string>
using namespace std;
struct wizard { 
	std::string name;
	int id;
	std::string password;
	std::string position_title; 
	float beard_length;
};

struct spellbook {
	std::string title;
	std::string author;
	int num_pages;
	int edition;
	int num_spells;
	float avg_success_rate;
	struct spell *s;
};

struct spell {
	std::string name;
	float success_rate;
	std::string effect; 
};

void get_wizard_firstL(ifstream& wiz, int& wizNum) ;
wizard * create_wizard(int wizNum) ;
void get_wizard_data(ifstream& wiz, struct wizard * create_wizard,int wizNum ) ;
void get_wizard_id(int& wizIDint) ;
void get_wizard_pass(string& wizPASS) ;
int check_wizard_login(int wizIDint, string wizPASS, struct wizard * create_wizard, int wizNum, int& wizTitle) ;
void greet_wizard(int wizTitle, struct wizard * create_wizard) ;
void get_spellbook_firstL(ifstream& spellb, int& spellbookNum) ;
spellbook * create_spellbook(int spellbookNum) ;
spell * create_spell(int& k) ;
void get_spell_data(struct spell * create_spell, int &g, ifstream& spellb);
void get_spellbook_data(ifstream& spellb, struct spellbook * create_spellbook, int spellbookNum ) ;
void get_spell_data(struct spell * create_spell, int &g, ifstream& spellb) ;
void sort_page(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) ;
void sort_page_print_1(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) ;
void sort_page_print_2(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) ;
void sort_effect_cout (int writeorcout, struct spellbook * create_spellbook, int spellbookNum, struct wizard * create_wizard, int wizTitle) ;
void sort_effect_ofstr (int writeorcout, struct spellbook * create_spellbook, int spellbookNum, struct wizard * create_wizard, int wizTitle) ;
void sort_success_pre(struct spellbook * create_spellbook, int spellbookNum, int writeorcout) ;
void sort_success(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) ;
void sort_success_print_1(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) ;
void sort_success_print_2(struct spellbook * create_spellbook, int spellbookNum, int writeorcout, int wizTitle, struct wizard * create_wizard) ;
void delete_info(wizard * create_wizard, int wizNum, spellbook * create_spellbook, int spellbookNum);
void spell_option(int& writeorcout, int spellbookNum, struct spellbook * create_spellbook, struct wizard * create_wizard, int wizTitle, int& option, int wizNum) ;
void spell_cout(int& writeorcout, int spellbookNum, struct spellbook * create_spellbook, struct wizard * create_wizard, int wizTitle, int option) ;	
void call_all_spell(ifstream& wiz, int wizIDint, string wizPASS, ifstream& spellb, int writeorcout, int& spellbookNum, int spellCounter, int wizNum, int& wizTitle, int& option) ;
void delete_info(wizard * create_wizard, int wizNum, spellbook * create_spellbook, int spellbookNum) ;
int IntegerError(string s, int& intgr) ;

